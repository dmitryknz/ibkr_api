
from ibkr_client import IBKRClient
import time

if __name__ == "__main__":
    ibkr = IBKRClient()

    ibkr.connect()
    time.sleep(1)  # небольшая задержка, чтобы соединение стабилизировалось

    ibkr.subscribe_to_market_data()

    for _ in range(10):
        price = ibkr.get_market_price()
        print(f"[INFO] Market price: {price}")
        time.sleep(2)

    ibkr.disconnect()
