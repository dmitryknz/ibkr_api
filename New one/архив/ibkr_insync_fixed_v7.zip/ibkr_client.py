# ibkr_client.py
from ib_insync import IB, Stock, LimitOrder

class IBKRClient:
    def __init__(self):
        self.ib = IB()
        self.contract = None
        self.ticker = None
        self.connected = False

    def connect(self, port=7497, ticker='UNH', exchange='SMART', currency='USD'):
        self.ib.disconnect()
        self.ib.connect('127.0.0.1', port, clientId=1)
        self.contract = Stock(ticker, exchange, currency)
        self.contract.primaryExchange = 'NYSE'  # Явно указать первичный рынок
        self.connected = True

    def disconnect(self):
        self.ib.disconnect()
        self.connected = False

    def get_market_price(self):
        if self.ticker:
            price = self.ticker.marketPrice()
            return float(price) if price is not None else None
        return None

    def place_order(self, action, qty, price):
        order = LimitOrder(action, qty, price)
        trade = self.ib.placeOrder(self.contract, order)
        return trade

    def cancel_all_orders(self):
        self.ib.cancelAllOrders()

    def subscribe_to_market_data(self):
        if self.contract:
            print(f"[DEBUG] Подписка на market data для: {self.contract.symbol}")
            self.ticker = self.ib.reqMktData(self.contract, '', snapshot=False, regulatorySnapshot=False)
            print(f"[DEBUG] Подписка запрошена, тикер объект: {self.ticker}")
