
import PySimpleGUI as sg
from ibkr_client import IBKRClient

sg.theme('DarkBlue3')

layout = [
    [sg.Text('IBKR API Port:'), sg.InputText('7497', key='PORT')],
    [sg.Button('Connect'), sg.Button('Exit')],
    [sg.Multiline(size=(60, 10), key='LOG', autoscroll=True)]
]

window = sg.Window('IBKR Connection Panel', layout)

ibkr = None

while True:
    event, values = window.read()
    if event == sg.WIN_CLOSED or event == 'Exit':
        if ibkr:
            ibkr.disconnect()
        break
    elif event == 'Connect':
        port = int(values['PORT'])
        window['LOG'].print(f'[INFO] Connecting to IBKR API on port {port}...')
        try:
            ibkr = IBKRClient(port=port)
            ibkr.connect()
            ibkr.subscribe_to_market_data()
            price = ibkr.get_market_price()
            window['LOG'].print(f'[INFO] Market Price for {ibkr.symbol}: {price}')
        except Exception as e:
            window['LOG'].print(f'[ERROR] {e}')
