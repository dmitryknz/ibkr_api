
from ib_insync import IB, Stock, util
import logging

logging.basicConfig(level=logging.DEBUG)

class IBKRClient:
    def __init__(self, symbol='UNH', exchange='SMART', currency='USD', primaryExchange='NYSE', port=7497):
        self.ib = IB()
        self.symbol = symbol
        self.exchange = exchange
        self.currency = currency
        self.primaryExchange = primaryExchange
        self.port = port
        self.contract = None
        self.ticker = None

    def connect(self):
        logging.debug(f"[DEBUG] Подключение к IBKR по порту {self.port}...")
        try:
            self.ib.connect('127.0.0.1', self.port, clientId=1)
            logging.debug("[DEBUG] Соединение установлено")

            self.contract = Stock(
                symbol=self.symbol,
                exchange=self.exchange,
                primaryExchange=self.primaryExchange,
                currency=self.currency
            )
            logging.debug(f"[DEBUG] Контракт создан: {self.contract}")
        except Exception as e:
            logging.error(f"[ERROR] Ошибка подключения к IBKR: {e}")
            raise

    def subscribe_to_market_data(self):
        if not self.contract:
            logging.error("[ERROR] Невозможно подписаться, contract = None")
            return

        self.ticker = self.ib.reqMktData(self.contract, snapshot=False, regulatorySnapshot=False)
        logging.debug(f"[DEBUG] Подписка на market data для: {self.symbol}")
        logging.debug(f"[DEBUG] Подписка завершена, тикер объект: {self.ticker}")

    def get_market_price(self):
        if self.ticker:
            return self.ticker.marketPrice()
        return None

    def disconnect(self):
        self.ib.disconnect()
        logging.debug("[DEBUG] Отключено от IBKR")
