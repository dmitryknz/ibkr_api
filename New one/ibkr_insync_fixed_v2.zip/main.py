# main.py
import wx
from ibkr_client import IBKRClient
from gui import MainFrame

def main():
    ibkr = IBKRClient()
    app = wx.App()
    frame = MainFrame(ibkr)
    frame.Show()
    app.MainLoop()
    ibkr.disconnect()

if __name__ == '__main__':
    main()
