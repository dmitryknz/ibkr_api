
from ib_insync import IB, Stock, LimitOrder
import threading
import time

class IBKRClient:
    def __init__(self):
        self.ib = IB()
        self.contract = None
        self.ticker = None
        self.connected = False

    def connect(self, port=7497, ticker='UNH', exchange='SMART', currency='USD'):
        print("[DEBUG] Подключение к IBKR...")
        self.ib.disconnect()
        self.ib.connect('127.0.0.1', port, clientId=1)

        print("[DEBUG] Запуск event loop через отдельный поток")
        threading.Thread(target=self.ib.run, daemon=True).start()
        time.sleep(1)

        self.contract = Stock(ticker, exchange, currency)
        self.contract.primaryExchange = 'NYSE'
        print(f"[DEBUG] Контракт создан: {self.contract}")

        self.connected = True
        print("[DEBUG] Соединение установлено")

    def disconnect(self):
        print("[DEBUG] Отключение от IBKR")
        self.ib.disconnect()
        self.connected = False

    def get_market_price(self):
        if self.ticker:
            print(f"[TRACE] ticker.bid: {self.ticker.bid}, ticker.ask: {self.ticker.ask}, ticker.last: {self.ticker.last}, close: {self.ticker.close}")
            if self.ticker.last is not None:
                return float(self.ticker.last)
            elif self.ticker.bid is not None and self.ticker.ask is not None:
                return (self.ticker.bid + self.ticker.ask) / 2
            elif self.ticker.close is not None:
                return float(self.ticker.close)
            else:
                print("[WARN] Все поля цены пусты: bid/ask/last/close")
        else:
            print("[WARN] Ticker объект ещё не инициализирован")
        return None

    def place_order(self, action, qty, price):
        print(f"[DEBUG] Размещение ордера: {action} {qty} @ {price}")
        order = LimitOrder(action, qty, price)
        trade = self.ib.placeOrder(self.contract, order)
        return trade

    def cancel_all_orders(self):
        print("[DEBUG] Отмена всех ордеров")
        self.ib.cancelAllOrders()

    def subscribe_to_market_data(self):
        if self.contract:
            print(f"[DEBUG] Подписка на market data для: {self.contract.symbol}")
            self.ticker = self.ib.reqMktData(self.contract, '', snapshot=False, regulatorySnapshot=False)
            print(f"[DEBUG] Подписка завершена, тикер объект: {self.ticker}")
        else:
            print("[ERROR] Невозможно подписаться, contract = None")
